/**
 * shocappExtractor.js
 * Definitive version — uses the actual SHOCAPP UI structure discovered via diagnose.js
 *
 * Key insights:
 *  - Filter dropdowns have stable IDs: #SelStatus, #SelData, #SelTabella
 *  - "Cerca" is an <a class="btn-support3">, not a <button>
 *  - The table mixes Stato values; we must filter rows by the Stato cell ourselves
 *  - Switching to "Sintesi" mode gives one row per flavor (cleaner)
 *
 * Workflow:
 *   1. Open SHOCAPP Lista Vaschette
 *   2. Set table to Sintesi mode
 *   3. Read with Stato=Mantenimento + Tutto il periodo  → stock B
 *   4. Set Stato=Esaurito + Ultimi 7 giorni             → sold last 7 days A
 *   5. Set Stato=Esaurito + Tutto il periodo            → all-time sold H
 *   6. Compute orders: target = ceil(A/7 * 10 days), order = max(0, target - B)
 */

import 'dotenv/config';
import { chromium } from 'playwright';
import XLSX from 'xlsx';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { generateOrderPdf } from './generatePdf.js';
import { sendTelegram } from './telegram.js';
import { sendEmail } from './email.js';
import logger from './logger.js';

const __dirname    = path.dirname(fileURLToPath(import.meta.url));
const ROOT         = path.join(__dirname, '..');
const OUTPUT_DIR   = path.join(ROOT, 'output');
const TEMPLATE_PATH = path.join(ROOT, 'gelato_flavors.xlsx');

const BASE  = 'https://gelateriafatamorgana.com/fata/tracking-manager/html';
const LOGIN = `${BASE}/login.php`;

// ─── ORDERING PARAMS ──────────────────────────────────────────────────────────
const COVER_DAYS  = 10;   // target stock = enough to cover this many days
const MAX_ORDER   = 8;    // safety cap per flavor

if (!fs.existsSync(OUTPUT_DIR)) fs.mkdirSync(OUTPUT_DIR, { recursive: true });

// ─── NAME MAP (SHOCAPP → template) ────────────────────────────────────────────
const NAME_MAP = {
  // ── CIOCCOLATO → C. (abbreviated) ──
  'CIOCCOLATO AL PIMENTO':                         'C. AL PIMENTO',
  "CIOCCOLATO CRUDO DEL PERU'":                    "C. CRUDO DEL PERU'",
  'CIOCCOLATO KENTUCKY':                           'C. KENTUCKY',
  'CIOCCOLATO LAPSANG SOUCHOUNG':                  'C. LAPSANG SOUCHOUNG',
  'CIOCCOLATO VENEZUELA':                          'C. VENEZUELA',
  'CIOCCOLATO WASABI':                             'C. WASABI',
  "CIOCCOLATO UGANDA PERLA D'AFRICA":              'C. UGANDA',
  'CIOCCOLATO MADAGASCAR':                         'C. MADAGASCAR',
  'CIOCCOLATO ROSEMARY':                           'C. ROSEMARY',
  'CIOCCOLATO AL LATTE GELATO':                    'C. AL LATTE GELATO',
  'CIOCCOLATO BIANCO':                             'C. BIANCO',
  'CIOCCOLATO E ARANCIA':                          'C. E ARANCIA',
  'CIOCCOLATO EQUADOR':                            'C. EQUADOR',
  'CIOCCOLATO VANIGLIA':                           'C. VANIGLIA',
  'CIOCCOLATO CANNELLA':                           'C. CANNELLA',
  'CIOCCOLATO AL WHISKY':                          'C. AL WHISKY',

  // ── CREMA → C. (template uses abbreviated form) ──
  'CREMA PASTICCIERA PARISI':                      'C. PASTICCIERA PARISI',
  'CREMA AGNESE':                                  'C. AGNESE',
  'CREMA FRAGOLE E MANDORLE':                      'C. FRAGOLE E MANDORLE',
  'CREMA ZENZERO MIELE DI CASTAGNO E LIMONE':      'C. ZENZERO',
  'CREMA ZENZERO':                                 'C. ZENZERO',
  'CREMA CANNELLA':                                'C. CANNELLA',
  'CREMA VANIGLIA':                                'C. VANIGLIA',
  'COCCO CREMA':                                   'COCCO C.',
  'GIANDUIA VARIEGATA':                            'V. GIANDUIA VARIEGATA',
  'EVERGREEN BRONTE VEGAN':                        'V.BRONTE GREEN',
  'NOCCIOLA AL FRUTTOSIO':                         'V. NOCCIOLA F.',
  'BANACHI, BANANA ARACHIDI & CARAMELLO':          'V. BANACHI',
  'CASTAGNA AL WHISKY':                            'V. CASTAGNA AL WHISKY',
  'CASTAGNA E MIRTO':                              'V. CASTAGNA E MIRTO',
  'FIOR DI CIOCCOLATO':                            'V. FIOR DI CIOCCOLATO',
  'BACIO DEL PRINCIPE':                            'BACIO',
  'LATTE MENTA E CIOCCOLATO':                      'MENTA E C.',
  'MELA MANDORLA E CANNELLA':                      'MELA M.C.',
  'MANGO SOLE DI SICILIA':                         'MANGO',
  'FRUTTI DI BOSCO(LAMPONE,RIBES,MORA,MIRTILLO)':  'FRUTTI DI BOSCO',
  'PANACEA (LATTE DI MANDORLA MENTA & GINSENG)':   'PANACEA',
  'PANACEA(LATTE DI MANDORLA MENTA & GINSENG)':    'PANACEA',
  'FIORI DI LAVANDA E FRAGOLINE DI NEMI':          'LAVANDA',
  'PISTACCHIO BRONTE':                             'P.BRONTE',
  'PISTACCHIO DI BRONTE':                          'P.BRONTE',
  'BRONTE':                                        'P.BRONTE',
  'PISTACCHIO LARNAKA, CIPRO':                     'PISTACCHIO LARNAKA',
  'PISTACCHIO LARNAKA , CIPRO':                    'PISTACCHIO LARNAKA',
  'PISTACCHIO LARNAKA':                            'PISTACCHIO LARNAKA',
  'RICOTTA ROMANA, CACAO CRUDO & PERA (LA-LA-LAND)':'RICOTTA E PERA',
  'BASILICO NOCI E MIELE':                         'BASILICO',
  'ANANAS E ZENZERO':                              'ANANAS',
  // ── New mappings from diagnose screenshots ──
  'STRACCHINO, ALBICOCCHE AL ROSMARINO & BRICIOLE DI CROSTATA': 'STRACCHINO ALBICOCCHA',
  'STRACCHINO ALBICOCCHE AL ROSMARINO & BRICIOLE DI CROSTATA':  'STRACCHINO ALBICOCCHA',
  'STRACCHINO CON SALSA DI PERE AL MARSALA & NOCI LARA':        'STRACCHINO PERA',
  'NOCCIOLA, BURRO & FIORI DI SALVIA':             'NOCCIOLA BURRO',
  'NOCCIOLA BURRO & FIORI DI SALVIA':              'NOCCIOLA BURRO',
  'PERE BELLE HELENE':                             'PEREBH',
  'COCONUT RICE CAKE':                             'COCONUT RICE CAKE',
  'ROSA KARKADE E ARANCIA':                        'ROSA E ARANCIA',
  'AVOCADO LIME E VINO BIANCO':                    'AVOCADO',
  'ARACHIDI COCCO E CIOCCOLATO':                   'ARACHIDI',
  'MELOGRANO WONDERFUL':                           'MELOGRANO',
  'TE VERDE MATCHA':                               'TE VERDE MATCHA',
  'CASTAGNA E MIRTO':                              'V. CASTAGNA E MIRTO',
  'CASTAGNA AL WHISKY':                            'V. CASTAGNA AL WHISKY',
  'ZABAIONE GELATO':                               'ZABAIONE GELATO',
  'ZABAIONE NEW':                                  'ZABAIONE GELATO',
  'CIOCCOLATO ROSEMARY':                           'C. ROSEMARY',
  'RICOTTA, MIELE E COCCO':                        'RICOTTA E COCCO',
  'RICOTTA E AGRUMI':                              'RICOTTA E AGRUMI',
  'CHEESECAKE MIRTILLI':                           'CHEESECAKE MIRTILLI',
  'BUONGIORNO AMORE':                              'BUONGIORNO AMORE',
};

const IGNORE = new Set([
  'PISTACCHIO SIRIANO',           // discontinued
  'CREMA MASCARPONE',
  'FAVE FRESCHE & PECORINO',
  'LIMONE & BASILICO',
  'STRAWBERRY FIELD FOREVER',
]);

const norm = s => String(s).toUpperCase().replace(/['']/g, "'").replace(/\s+/g, ' ').trim();

// ─── Login ───────────────────────────────────────────────────────────────────
async function login(page) {
  await page.goto(LOGIN, { waitUntil: 'domcontentloaded', timeout: 30000 });
  await page.fill('input[name="username"]', process.env.GELATERIA_USER);
  await page.fill('input[name="password"]', process.env.GELATERIA_PASS);
  await Promise.all([
    page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 30000 }),
    page.click('button[type="submit"], input[type="submit"]'),
  ]);
  if (page.url().includes('login')) throw new Error('Login failed — check .env');
  logger.info('Login OK');
}

// ─── Open SHOCAPP page ───────────────────────────────────────────────────────
async function openShocapp(page) {
  const link = page.locator('a:has-text("SHOCAPP")').first();
  if (await link.count()) await link.click();
  await page.waitForSelector('table', { timeout: 15000 });
  await page.waitForTimeout(800);
}

// ─── Find and set the TABLE row-per-page dropdown (not the date format one) ──
// Multiple <select> elements exist on the page. We want the one INSIDE the
// table area whose options are 10/25/50/100 etc.
async function setTablePageSize(page) {
  const result = await page.evaluate(() => {
    const selects = Array.from(document.querySelectorAll('select'));
    for (const sel of selects) {
      const opts = Array.from(sel.options).map(o => o.value);
      // The table page-size dropdown has numeric options like 10, 25, 50, 100
      const numericOpts = opts.map(o => parseInt(o)).filter(n => !isNaN(n));
      if (numericOpts.length >= 2 && numericOpts.includes(100)) {
        sel.value = '100';
        sel.dispatchEvent(new Event('change', { bubbles: true }));
        return { found: true, opts, set: 100 };
      }
    }
    return { found: false };
  });
  if (result.found) logger.info(`  page-size set to ${result.set} (options: ${result.opts.join(',')})`);
  else logger.warn('  table page-size dropdown not found');
  await page.waitForTimeout(800);
}

// ─── Set a multi-select dropdown to ONE option (uncheck all others first) ───
//
// SHOCAPP dropdowns are checkbox-style multi-select. Clicking an option toggles
// it. We need to:
//   1. Open the dropdown
//   2. Uncheck every currently-checked item (click each one that's selected)
//   3. Click the target option to check it
//   4. Press Escape to close the dropdown
async function pickDropdown(page, triggerId, optionText) {
  for (let attempt = 1; attempt <= 3; attempt++) {
    // Step 1: Open the dropdown
    const opened = await page.evaluate(({ triggerId }) => {
      const triggers = Array.from(document.querySelectorAll('button[data-toggle="dropdown"]'));
      const btn = triggers.find(b => b.dataset?.id === triggerId);
      if (!btn) return { ok: false, error: 'trigger not found' };

      // Open via jQuery if available
      if (window.jQuery) window.jQuery(btn).dropdown('show');
      else if (window.$)  window.$(btn).dropdown('show');
      else {
        btn.click();
        btn.setAttribute('aria-expanded', 'true');
        const m = btn.parentElement?.querySelector('.dropdown-menu');
        if (m) { m.classList.add('show'); m.style.display = 'block'; }
      }
      return { ok: true };
    }, { triggerId });

    if (!opened.ok) {
      logger.warn(`pickDropdown ${triggerId}: ${opened.error}`);
      await page.waitForTimeout(400);
      continue;
    }

    await page.waitForTimeout(300);

    // Step 2: Uncheck everything currently checked (except the target)
    // and Step 3: Click the target if not already checked.
    const result = await page.evaluate(({ triggerId, optionText }) => {
      const triggers = Array.from(document.querySelectorAll('button[data-toggle="dropdown"]'));
      const btn = triggers.find(b => b.dataset?.id === triggerId);
      if (!btn) return { ok: false, error: 'trigger lost' };

      let menu = btn.parentElement?.querySelector('.dropdown-menu');
      if (!menu) {
        menu = btn.nextElementSibling;
        while (menu && !menu.classList.contains('dropdown-menu')) menu = menu.nextElementSibling;
      }
      if (!menu) return { ok: false, error: 'menu not found' };

      menu.classList.add('show');
      menu.style.display = 'block';

      // Every option is an <a> or <li> with a checkbox or "selected"/"active" class
      const options = Array.from(menu.querySelectorAll('a, li'));
      const target = optionText.toUpperCase().trim();

      // An item is "currently selected" if:
      //  - it has a checkbox child that's :checked
      //  - or it has class active/selected
      //  - or its <i> child has a check-icon class
      const isChecked = (el) => {
        const cb = el.querySelector('input[type="checkbox"]');
        if (cb && cb.checked) return true;
        if (el.classList.contains('active') || el.classList.contains('selected')) return true;
        const icon = el.querySelector('i, .icon, svg');
        if (icon && /check|tick|fa-check/i.test(icon.className.baseVal || icon.className || '')) return true;
        return false;
      };

      const unchecked = [];
      const result = { ok: false, checked: false, available: [] };

      for (const o of options) {
        const text = (o.textContent || '').trim();
        if (!text) continue;
        result.available.push(text);

        // Currently checked but not the target — UNCHECK it
        if (isChecked(o) && text.toUpperCase() !== target) {
          o.click();
          unchecked.push(text);
        }
      }

      // Now find the target option and check it if needed
      const targetOpt = options.find(o => (o.textContent || '').trim().toUpperCase() === target);
      if (!targetOpt) return { ok: false, error: 'target not in menu', available: result.available };

      if (!isChecked(targetOpt)) {
        targetOpt.click();
        result.checked = true;
      } else {
        result.checked = false; // was already checked
      }

      result.ok = true;
      result.unchecked = unchecked;
      return result;
    }, { triggerId, optionText });

    if (!result.ok) {
      logger.warn(`pickDropdown ${triggerId} -> "${optionText}": ${result.error}`);
      if (result.available) logger.warn(`  options: ${result.available.slice(0, 10).join(' | ')}`);
      await page.waitForTimeout(400);
      continue;
    }

    if (result.unchecked?.length) {
      logger.info(`  unchecked: ${result.unchecked.join(', ')}`);
    }

    // Step 4: Close the dropdown with Escape
    await page.keyboard.press('Escape');
    await page.waitForTimeout(400);

    // Verify the button now reflects our selection
    const verified = await page.evaluate(({ triggerId, optionText }) => {
      const triggers = Array.from(document.querySelectorAll('button[data-toggle="dropdown"]'));
      const btn = triggers.find(b => b.dataset?.id === triggerId);
      if (!btn) return { ok: false, text: '' };
      const txt = (btn.textContent || '').toUpperCase().trim();
      return { ok: txt.includes(optionText.toUpperCase().trim()), text: txt };
    }, { triggerId, optionText });

    if (verified.ok) return true;
    logger.warn(`  attempt ${attempt}: button shows "${verified.text}", expected "${optionText}"`);
    await page.waitForTimeout(500);
  }

  logger.error(`pickDropdown ${triggerId} -> "${optionText}" FAILED`);
  return false;
}

// ─── Click "Cerca" (which is actually an <a>) ────────────────────────────────
// ─── Get a fingerprint of the current data table (for change detection) ─────
async function tableFingerprint(page) {
  return page.evaluate(() => {
    const tables = Array.from(document.querySelectorAll('table'));
    let best = null, bestRows = 0;
    for (const t of tables) {
      const headerText = (t.querySelector('thead')?.textContent || '').toUpperCase();
      if (!headerText.includes('GUSTO')) continue;
      const rc = t.querySelectorAll('tbody tr').length;
      if (rc > bestRows) { bestRows = rc; best = t; }
    }
    if (!best) return 'NO_TABLE';
    const rows = Array.from(best.querySelectorAll('tbody tr'));
    // Fingerprint = row count + concatenation of first cell of every row + all qty cells
    let fp = rows.length + '|';
    for (const tr of rows) {
      const cells = Array.from(tr.querySelectorAll('td')).map(td => (td.textContent || '').trim());
      fp += cells.join(',') + ';';
    }
    return fp;
  });
}

// ─── Click "Cerca" and WAIT until the table content actually changes ────────
async function clickCerca(page, prevFingerprint = null) {
  const cerca = page.locator('a.btn-support3:has-text("Cerca"), a:has-text("Cerca"), .btn:has-text("Cerca")').first();
  if (!(await cerca.count())) {
    logger.warn('Cerca link not found');
    await page.waitForTimeout(2000);
    return;
  }

  await cerca.click({ timeout: 3000 }).catch(() => {});

  // If we have a previous fingerprint, poll until the table differs from it.
  if (prevFingerprint !== null) {
    const maxWait = 15000;   // up to 15s for AJAX
    const interval = 400;
    let waited = 0;
    while (waited < maxWait) {
      await page.waitForTimeout(interval);
      waited += interval;
      const current = await tableFingerprint(page);
      if (current !== prevFingerprint && current !== 'NO_TABLE') {
        logger.info(`  table refreshed after ${waited}ms`);
        await page.waitForTimeout(500); // small settle
        return;
      }
    }
    logger.warn(`  ⚠️ table did NOT change after ${maxWait}ms — data may be stale`);
  } else {
    // First load — just wait a fixed amount
    await page.waitForTimeout(2500);
  }
}

// ─── Read table, KEEPING the Stato column so we can filter ourselves ────────
async function readTable(page, label) {
  await page.waitForTimeout(400);
  fs.writeFileSync(path.join(OUTPUT_DIR, `debug_${label}.html`), await page.content());
  await page.screenshot({ path: path.join(OUTPUT_DIR, `screenshot_${label}.png`) }).catch(() => {});

  return page.evaluate(() => {
    // Pick the data table — the one with most rows, must contain a "Gusto" header
    const tables = Array.from(document.querySelectorAll('table'));
    let best = null, bestRows = 0;
    for (const t of tables) {
      const headerText = (t.querySelector('thead')?.textContent || '').toUpperCase();
      if (!headerText.includes('GUSTO')) continue;
      const rc = t.querySelectorAll('tbody tr').length;
      if (rc > bestRows) { bestRows = rc; best = t; }
    }
    if (!best) return [];

    // Determine column indexes from header
    const headerCells = Array.from(best.querySelectorAll('thead th, thead td'));
    const headers = headerCells.map(h => (h.textContent || '').trim().toUpperCase());
    const gustoIdx = headers.findIndex(h => h.includes('GUSTO'));
    const statoIdx = headers.findIndex(h => h.includes('STATO'));
    const vasIdx   = headers.findIndex(h => h.includes('VASCHE'));

    const out = [];
    for (const tr of best.querySelectorAll('tbody tr')) {
      const cells = Array.from(tr.querySelectorAll('td')).map(td => (td.textContent || '').trim());
      if (cells.length < 3) continue;
      const flavor = gustoIdx >= 0 ? cells[gustoIdx] : cells[1];
      const stato  = statoIdx >= 0 ? cells[statoIdx] : '';
      const qty    = parseInt((cells[vasIdx >= 0 ? vasIdx : 4] || '').replace(/[^0-9]/g, ''));
      if (!flavor || flavor.length < 2) continue;
      if (flavor.toLowerCase().includes('peso')) continue;
      if (!isNaN(qty) && qty > 0) out.push({ flavor, stato, qty });
    }
    return out;
  });
}

// ─── Filter rows by exact Stato value, then aggregate ───────────────────────
function filterByStato(rows, stato) {
  return rows.filter(r => norm(r.stato) === norm(stato));
}

function aggregate(rows) {
  const m = {};
  for (const r of rows) m[r.flavor] = (m[r.flavor] ?? 0) + r.qty;
  return Object.entries(m).map(([flavor, qty]) => ({ flavor, qty }));
}

// ─── Map names to template ──────────────────────────────────────────────────
function loadTemplateNames() {
  const wb = XLSX.readFile(TEMPLATE_PATH);
  const ws = wb.Sheets['Flavors'];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1 });
  const set = new Set();
  for (const row of rows.slice(1)) {
    for (const c of [0, 2, 4, 6]) {
      const v = row[c];
      if (v && !['ORDINE', 'TOTAL:', 'Varie'].includes(String(v).trim())) set.add(norm(v));
    }
  }
  return set;
}

function mapName(s, set) {
  const n = norm(s);
  if (set.has(n)) return n;
  if (NAME_MAP[n]) return norm(NAME_MAP[n]);
  if (IGNORE.has(n)) return null;
  return null;
}

function aggregateAndMap(rawRows, set) {
  const m = {};
  const unmatched = [];
  for (const r of rawRows) {
    const k = mapName(r.flavor, set);
    if (k) m[k] = (m[k] ?? 0) + r.qty;
    else if (!IGNORE.has(norm(r.flavor))) unmatched.push(r.flavor);
  }
  if (unmatched.length) logger.warn(`Unmatched: ${[...new Set(unmatched)].join(', ')}`);
  return m;
}

// ─── Decision logic — simple, slightly generous ─────────────────────────────
// Rule:
//   if sold_last_7_days == 0  →  don't order  (no demand)
//   else                       →  order = max(0, (sold + 1) - stock)
//
// The "+1" is a small buffer: you stay one vaschetta ahead of last week's pace.
// Example: sold 5, stock 5 → order 1.  Sold 9, stock 4 → order 6.  Sold 0 → 0.
function decideOrders({ stock, sold7d, hist }) {
  const flavors = new Set([...Object.keys(stock), ...Object.keys(sold7d), ...Object.keys(hist)]);
  const decisions = [];

  for (const f of flavors) {
    const A = sold7d[f] ?? 0;   // sold last 7 days
    const B = stock[f]  ?? 0;   // current stock
    const H = hist[f]   ?? 0;   // historical (info only)

    let order, reason;
    if (A === 0) {
      order = 0;
      reason = 'nessuna vendita 7gg';
    } else {
      const target = A + 1;     // small generosity: cover last week's pace + 1
      order = Math.max(0, target - B);
      reason = order === 0
        ? `scorta (${B}) copre vendite (${A})`
        : `vendite ${A} + 1 buffer - scorta ${B}`;
    }

    decisions.push({
      flavor: f, stock: B, sold7d: A, hist: H,
      dailyRate: A > 0 ? (A / 7).toFixed(2) : '0',
      target: A === 0 ? 0 : A + 1, order, reason,
    });
  }
  return decisions.sort((a, b) => b.order - a.order || b.sold7d - a.sold7d);
}

// ─── Excel + PDF ────────────────────────────────────────────────────────────
function fillTemplate(orderMap) {
  const wb = XLSX.readFile(TEMPLATE_PATH);
  const ws = wb.Sheets['Flavors'];
  const ref = XLSX.utils.decode_range(ws['!ref']);
  for (let R = ref.s.r; R <= ref.e.r; R++) {
    for (let C = ref.s.c; C <= ref.e.c; C += 2) {
      const fc = XLSX.utils.encode_cell({ r: R, c: C });
      const oc = XLSX.utils.encode_cell({ r: R, c: C + 1 });
      if (!ws[fc]?.v) continue;
      const key = norm(ws[fc].v);
      if (['ORDINE', 'TOTAL:', 'VARIE'].includes(key)) continue;
      const qty = orderMap[key];
      ws[oc] = qty > 0 ? { t: 'n', v: qty } : { t: 's', v: '' };
    }
  }
  const p = path.join(OUTPUT_DIR, 'shocapp_template_filled.xlsx');
  XLSX.writeFile(wb, p);
  return p;
}

function saveDecisionsExcel(decisions) {
  const headers = ['Gusto', 'Scorta', 'Venduti 7gg', 'Venduti storici', 'Rate/giorno', 'Target', 'Da Ordinare', 'Motivo'];
  const rows = decisions.map(d => [d.flavor, d.stock, d.sold7d, d.hist, d.dailyRate, d.target, d.order, d.reason]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet([headers, ...rows]), 'Decisioni');
  XLSX.writeFile(wb, path.join(OUTPUT_DIR, 'shocapp_da_ordinare.xlsx'));
}

function saveRaw(map, filename, sheetName) {
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb,
    XLSX.utils.aoa_to_sheet([['flavor', 'qty'], ...Object.entries(map)]), sheetName);
  XLSX.writeFile(wb, path.join(OUTPUT_DIR, filename));
}

// ─── Main ─────────────────────────────────────────────────────────────────────
export async function runExtraction() {
  let browser;
  try {
    const t0 = Date.now();
    browser = await chromium.launch({ headless: true });
    const page = await browser.newPage();

    await login(page);
    await openShocapp(page);

    // Make sure we're in Sintesi mode (one row per flavor, aggregated)
    await pickDropdown(page, 'SelTabella', 'Sintesi');

    // ── 1. Filter to Mantenimento + Tutto il periodo ──
    logger.info('▸ Mantenimento, tutto il periodo (Sintesi)');
    await pickDropdown(page, 'SelStatus', 'Mantenimento');
    await pickDropdown(page, 'SelData',   'Tutto il periodo');
    await clickCerca(page);   // first load — no fingerprint
    await setTablePageSize(page);
    const stockRows = await readTable(page, 'Mantenimento');
    logger.info(`  ${stockRows.length} righe`);
    let fp = await tableFingerprint(page);

    // ── 2. Esaurito + Ultimi 7 giorni ──
    logger.info('▸ Esaurito, ultimi 7 giorni (Sintesi)');
    await pickDropdown(page, 'SelStatus', 'Esaurito');
    await pickDropdown(page, 'SelData',   'Ultimi 7 giorni');
    await clickCerca(page, fp);   // wait until table differs from Mantenimento
    await setTablePageSize(page);
    const sold7dRows = await readTable(page, 'Esaurito_7gg');
    logger.info(`  ${sold7dRows.length} righe`);
    fp = await tableFingerprint(page);

    // ── 3. Esaurito + Tutto il periodo ──
    logger.info('▸ Esaurito, tutto il periodo (Sintesi)');
    await pickDropdown(page, 'SelData', 'Tutto il periodo');
    await clickCerca(page, fp);   // wait until table differs from Esaurito 7gg
    await setTablePageSize(page);
    const histRows = await readTable(page, 'Esaurito_storico');
    logger.info(`  ${histRows.length} righe`);

    await browser.close(); browser = null;

    // ── Sanity check — ABORT if the filters obviously did nothing ──
    const sig = arr => arr.map(r => `${r.flavor}:${r.qty}`).sort().join('|');
    if (sig(stockRows) === sig(sold7dRows)) {
      throw new Error(
        'Filtro Stato non funziona: Mantenimento e Esaurito hanno restituito gli stessi dati. ' +
        'Controlla output/debug_*.html. Riprova tra qualche secondo.'
      );
    }
    if (sig(sold7dRows) === sig(histRows)) {
      logger.warn('⚠️  Sold7d === Hist — il filtro Periodo non ha funzionato!');
    }

    // ── Aggregate raw counts (before name mapping) ──
    const stockAgg  = aggregate(stockRows);
    const sold7dAgg = aggregate(sold7dRows);
    const histAgg   = aggregate(histRows);

    logger.info(`Aggregati: stock=${stockAgg.length}, sold7d=${sold7dAgg.length}, hist=${histAgg.length} gusti`);

    // ── Map to template names ──
    const set    = loadTemplateNames();
    const stock  = aggregateAndMap(stockRows,  set);
    const sold7d = aggregateAndMap(sold7dRows, set);
    const hist   = aggregateAndMap(histRows,   set);

    saveRaw(stock,  'shocapp_mantenimento.xlsx',     'Mantenimento');
    saveRaw(sold7d, 'shocapp_esaurito_7gg.xlsx',     'Esaurito 7gg');
    saveRaw(hist,   'shocapp_esaurito_storico.xlsx', 'Storico');

    const decisions = decideOrders({ stock, sold7d, hist });
    saveDecisionsExcel(decisions);

    const orderMap = {};
    for (const d of decisions) if (d.order > 0) orderMap[d.flavor] = d.order;

    const filledPath = fillTemplate(orderMap);
    const pdfPath    = await generateOrderPdf(orderMap);

    // ── Verify: every order in orderMap should map to a template row ──
    const templateNames = loadTemplateNames();
    const missingFromTemplate = [];
    for (const [name, qty] of Object.entries(orderMap)) {
      if (qty > 0 && !templateNames.has(name)) missingFromTemplate.push(`${name}=${qty}`);
    }
    if (missingFromTemplate.length) {
      logger.warn(`⚠️ ${missingFromTemplate.length} ordini NON appariranno nel PDF (nome non trovato nel template):`);
      for (const m of missingFromTemplate) logger.warn(`    ${m}`);
    }

    const ordered = decisions.filter(d => d.order > 0);
    const total   = ordered.reduce((s, d) => s + d.order, 0);
    const totalInPdf = ordered.filter(d => templateNames.has(d.flavor)).reduce((s, d) => s + d.order, 0);
    const dt      = ((Date.now() - t0) / 1000).toFixed(1);

    logger.info(`✓ ${ordered.length} gusti, ${total} vaschette calcolate, ${totalInPdf} mostrate nel PDF (in ${dt}s)`);
    logger.info('Top decisioni:');
    for (const d of ordered.slice(0, 12)) {
      logger.info(`  ${d.flavor.padEnd(28)} stock=${d.stock} sold7d=${d.sold7d} → ${d.order}  (${d.reason})`);
    }

    return { filledPath, pdfPath, decisions, orderMap };
  } catch (err) {
    if (browser) await browser.close();
    logger.error('Extraction failed:', err.message);
    throw err;
  }
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const r = await runExtraction();
  if (process.env.AUTO_SEND_TELEGRAM !== 'false' && process.env.TELEGRAM_BOT_TOKEN)
    await sendTelegram([r.filledPath, r.pdfPath], '✅ Estrazione completata');
  if (process.env.AUTO_SEND_EMAIL !== 'false' && process.env.EMAIL_USER)
    await sendEmail([r.filledPath, r.pdfPath], 'Report settimanale Fata Morgana');
}
